package euphoria.psycho.library
import java.io.File
interface FileClickListener {
    fun onClick(f: File?)
}